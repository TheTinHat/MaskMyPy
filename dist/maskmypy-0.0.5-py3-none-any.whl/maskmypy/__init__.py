from .donut import Donut, Donut_MaxK, Donut_Multiply
from .street import Street

name = 'maskmypy'